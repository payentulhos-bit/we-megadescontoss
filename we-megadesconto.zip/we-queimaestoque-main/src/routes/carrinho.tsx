import { createFileRoute, Link } from "@tanstack/react-router";
import { Trash2 } from "lucide-react";

import { StoreFooter } from "@/components/store/StoreFooter";
import { StoreHeader } from "@/components/store/StoreHeader";
import { useCart } from "@/lib/cart";
import { PRODUCT, formatBRL } from "@/lib/product";

export const Route = createFileRoute("/carrinho")({
  head: () => ({
    meta: [
      { title: "Sua cesta — Wepink Heaven" },
      {
        name: "description",
        content: "Revise os itens da sua cesta e finalize a compra do Heaven 100ml por Pix.",
      },
      { property: "og:title", content: "Sua cesta — Wepink Heaven" },
      { property: "og:description", content: "Revise os itens e finalize sua compra por Pix." },
    ],
  }),
  component: CartPage,
});

function CartPage() {
  const { items, totalCents, setQuantity, remove } = useCart();

  return (
    <div className="min-h-screen bg-background">
      <StoreHeader />

      <main className="mx-auto max-w-4xl px-4 py-10">
        <h1 className="text-3xl font-bold">sua cesta</h1>

        {items.length === 0 ? (
          <div className="mt-8 rounded-3xl bg-blush p-10 text-center">
            <p className="text-muted-foreground">Sua cesta está vazia.</p>
            <Link
              to="/"
              className="mt-6 inline-flex rounded-4xl bg-primary px-8 py-3 text-sm font-bold text-primary-foreground"
            >
              Ver o Heaven 100ml
            </Link>
          </div>
        ) : (
          <>
            <ul className="mt-8 space-y-4">
              {items.map((item) => (
                <li
                  key={item.sku}
                  className="flex flex-wrap items-center gap-4 rounded-3xl border border-border p-4"
                >
                  <img
                    src={PRODUCT.images[0]}
                    alt={item.name}
                    className="size-20 rounded-2xl object-cover"
                    loading="lazy"
                  />
                  <div className="min-w-40 flex-1">
                    <p className="text-sm font-bold">{item.name}</p>
                    <p className="text-sm text-muted-foreground">{formatBRL(item.priceCents)}</p>
                  </div>
                  <input
                    type="number"
                    min={1}
                    max={99}
                    value={item.quantity}
                    onChange={(e) => setQuantity(item.sku, Number(e.target.value))}
                    aria-label="Quantidade"
                    className="w-16 rounded-2xl border border-border px-3 py-2 text-center text-sm"
                  />
                  <p className="w-24 text-right text-sm font-bold">
                    {formatBRL(item.priceCents * item.quantity)}
                  </p>
                  <button
                    onClick={() => remove(item.sku)}
                    aria-label="Remover item"
                    className="text-muted-foreground transition-colors hover:text-destructive"
                  >
                    <Trash2 className="size-4" />
                  </button>
                </li>
              ))}
            </ul>

            <div className="mt-8 rounded-3xl bg-blush p-6">
              <div className="flex items-center justify-between text-lg font-bold">
                <span>Total</span>
                <span className="text-primary">{formatBRL(totalCents)}</span>
              </div>
              <Link
                to="/checkout"
                className="mt-6 block rounded-4xl bg-primary py-4 text-center text-sm font-bold tracking-widest text-primary-foreground uppercase"
              >
                Finalizar compra
              </Link>
            </div>
          </>
        )}
      </main>

      <StoreFooter />
    </div>
  );
}
