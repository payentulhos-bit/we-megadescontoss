import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { CheckCircle2, Clock3, LockKeyhole, PackageCheck, Truck } from "lucide-react";
import { toast } from "sonner";
import QRCode from "qrcode";
import { useEffect, useRef, useState } from "react";

import { StoreFooter } from "@/components/store/StoreFooter";
import { StoreHeader } from "@/components/store/StoreHeader";
import { Button } from "@/components/ui/button";
import { PRODUCT, formatBRL } from "@/lib/product";
import { getOrderPublic } from "@/lib/checkout.functions";
import { markPurchaseForMeta } from "@/lib/meta.functions";
import { readMarketingConsent, trackMetaEvent } from "@/lib/meta-browser";

export const Route = createFileRoute("/pedido/$orderId")({
  head: () => ({
    meta: [
      { title: "Pague com Pix — Wepink Heaven" },
      {
        name: "description",
        content: "Copie o código Pix e conclua o pagamento do seu pedido Wepink Heaven.",
      },
      { property: "og:title", content: "Pague com Pix — Wepink Heaven" },
      { property: "og:description", content: "Conclua o pagamento do seu pedido por Pix." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: OrderPage,
});

type OrderItem = {
  sku: string;
  name: string;
  priceCents: number;
  quantity: number;
};

function isOrderItem(item: unknown): item is OrderItem {
  if (!item || typeof item !== "object") return false;
  const candidate = item as Record<string, unknown>;
  return (
    typeof candidate["sku"] === "string" &&
    typeof candidate["name"] === "string" &&
    typeof candidate["priceCents"] === "number" &&
    typeof candidate["quantity"] === "number"
  );
}

const STATUS_COPY: Record<string, { label: string; detail: string }> = {
  awaiting_payment: {
    label: "Aguardando pagamento",
    detail: "Assim que você pagar, a confirmação aparecerá automaticamente nesta página.",
  },
  paid: {
    label: "Pagamento confirmado",
    detail: "Recebemos seu pagamento e seu pedido já está confirmado.",
  },
  failed: {
    label: "Pagamento não concluído",
    detail: "Não foi possível concluir este pagamento.",
  },
};

function OrderPage() {
  const { orderId } = Route.useParams();
  const fetchOrder = useServerFn(getOrderPublic);
  const reportPurchase = useServerFn(markPurchaseForMeta);
  const reported = useRef(false);
  const [generatedQrCode, setGeneratedQrCode] = useState<string | null>(null);
  const [providerImageFailed, setProviderImageFailed] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ["order", orderId],
    queryFn: () => fetchOrder({ data: { orderId } }),
    refetchInterval: 15000,
  });

  useEffect(() => {
    if (reported.current || data?.status !== "paid") return;
    reported.current = true;
    const eventId = `purchase-${data.id}`;
    trackMetaEvent("Purchase", data.amount_cents / 100, eventId);
    if (readMarketingConsent()?.accepted === true) {
      reportPurchase({ data: { orderId: data.id, consent: true } }).catch(() => undefined);
    }
  }, [data, reportPurchase]);

  useEffect(() => {
    const copyPaste = data?.pix_copy_paste;
    if (!copyPaste) {
      setGeneratedQrCode(null);
      return;
    }

    let active = true;
    QRCode.toDataURL(copyPaste, {
      errorCorrectionLevel: "M",
      margin: 2,
      width: 320,
    })
      .then((image) => {
        if (active) setGeneratedQrCode(image);
      })
      .catch(() => {
        if (active) setGeneratedQrCode(null);
      });

    return () => {
      active = false;
    };
  }, [data?.pix_copy_paste]);

  const providerQrCode = data?.pix_qr_code?.trim() ?? "";
  const providerImage = /^(data:image\/|https?:\/\/)/i.test(providerQrCode)
    ? providerQrCode
    : null;
  const qrCodeImage = providerImage && !providerImageFailed ? providerImage : generatedQrCode;
  const orderItems = Array.isArray(data?.items) ? data.items.filter(isOrderItem) : [];
  const firstName = data?.customer_name.trim().split(/\s+/)[0] ?? "";
  const deliveryAddress = [data?.shipping_address, data?.shipping_zip]
    .filter((value): value is string => Boolean(value?.trim()))
    .join(" · ");
  const statusCopy = data ? (STATUS_COPY[data.status] ?? STATUS_COPY["awaiting_payment"]) : null;

  useEffect(() => {
    setProviderImageFailed(false);
  }, [providerImage]);

  return (
    <div className="min-h-screen bg-background">
      <StoreHeader />

      <main className="mx-auto max-w-5xl px-4 py-10 sm:py-12">
        {isLoading && <p className="text-muted-foreground">Carregando seu pedido...</p>}

        {!isLoading && !data && (
          <div className="rounded-3xl bg-blush p-8 text-center">
            <h1 className="text-2xl font-bold">Pedido não encontrado</h1>
            <Link to="/" className="mt-4 inline-block text-sm font-bold text-primary">
              Voltar para a loja
            </Link>
          </div>
        )}

        {data && (
          <div>
            <div className="mb-8 text-center">
              <span className="inline-flex items-center gap-2 text-sm font-bold text-success">
                {data.status === "paid" ? (
                  <CheckCircle2 className="size-5" />
                ) : (
                  <Clock3 className="size-5" />
                )}
                {statusCopy?.label}
              </span>
              <h1 className="mt-2 text-2xl font-bold sm:text-3xl">
                {data.status === "paid"
                  ? `Tudo certo${firstName ? `, ${firstName}` : ""}!`
                  : `Finalize seu pedido${firstName ? `, ${firstName}` : ""}`}
              </h1>
              <p className="mx-auto mt-2 max-w-xl text-sm text-muted-foreground">
                {statusCopy?.detail}
              </p>
            </div>

            <div className="grid items-start gap-6 lg:grid-cols-[0.9fr_1.1fr]">
              <aside className="order-1 rounded-2xl border border-border bg-card p-5 shadow-card lg:sticky lg:top-6">
                <div className="flex items-center justify-between gap-4 border-b border-border pb-4">
                  <div>
                    <p className="text-xs font-bold text-muted-foreground uppercase">Seu pedido</p>
                    <p className="mt-1 text-sm font-bold">#{String(data.id).slice(0, 8).toUpperCase()}</p>
                  </div>
                  <PackageCheck className="size-6 text-primary" />
                </div>

                <ul className="divide-y divide-border">
                  {orderItems.map((item) => (
                    <li key={item.sku} className="flex gap-4 py-5">
                      <img
                        src={item.sku === PRODUCT.sku ? PRODUCT.images[0] : PRODUCT.images[0]}
                        alt={item.name}
                        className="size-20 shrink-0 rounded-xl border border-border object-cover"
                      />
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-bold leading-snug">{item.name}</p>
                        <p className="mt-1 text-xs text-muted-foreground">
                          Quantidade: {item.quantity} · {formatBRL(item.priceCents)} cada
                        </p>
                        <p className="mt-2 text-sm font-bold text-primary">
                          {formatBRL(item.priceCents * item.quantity)}
                        </p>
                      </div>
                    </li>
                  ))}
                </ul>

                {deliveryAddress && (
                  <div className="flex gap-3 border-t border-border py-4 text-sm">
                    <Truck className="mt-0.5 size-4 shrink-0 text-primary" />
                    <div>
                      <p className="font-bold">Entrega</p>
                      <p className="mt-1 text-muted-foreground">{deliveryAddress}</p>
                    </div>
                  </div>
                )}

                <div className="flex items-end justify-between gap-4 border-t border-border pt-4">
                  <span className="text-sm font-bold">Total do pedido</span>
                  <span className="font-display text-2xl font-extrabold text-primary">
                    {formatBRL(data.amount_cents)}
                  </span>
                </div>
              </aside>

              <section className="order-2 rounded-2xl bg-blush p-5 sm:p-7">
                <div className="text-center">
                  <h2 className="text-xl font-bold">
                    {data.status === "paid" ? "Pix recebido" : "Pague com Pix"}
                  </h2>
                  {data.status !== "paid" && (
                    <p className="mt-1 text-sm text-muted-foreground">
                      Escaneie o QR Code ou copie o código abaixo.
                    </p>
                  )}
                </div>

                {qrCodeImage && data.status !== "paid" && (
                  <img
                    src={qrCodeImage}
                    alt="QR Code Pix do pedido"
                    className="mx-auto mt-6 size-64 max-w-full rounded-2xl bg-background p-3 shadow-card"
                    onError={() => setProviderImageFailed(true)}
                  />
                )}

                {data.pix_copy_paste && data.status !== "paid" && (
                  <div className="mt-6">
                    <p className="text-xs font-bold uppercase">Pix copia e cola</p>
                    <p className="mt-2 max-h-24 overflow-y-auto rounded-xl bg-background p-4 text-xs break-all">
                      {data.pix_copy_paste}
                    </p>
                    <Button
                      type="button"
                      onClick={async () => {
                        const copyPaste = data.pix_copy_paste;
                        if (!copyPaste) return;
                        await navigator.clipboard.writeText(copyPaste);
                        toast.success("Código Pix copiado");
                      }}
                      className="mt-4 h-12 w-full rounded-full font-bold"
                    >
                      Copiar código Pix
                    </Button>
                  </div>
                )}

                {!data.pix_copy_paste && !data.pix_qr_code && data.status !== "paid" && (
                  <p className="mt-6 text-center text-sm text-muted-foreground">
                    Estamos preparando seu Pix. Esta página atualiza automaticamente.
                  </p>
                )}

                <p className="mt-6 flex items-center justify-center gap-2 text-center text-xs text-muted-foreground">
                  <LockKeyhole className="size-4" /> Pagamento seguro e pedido protegido
                </p>
              </section>
            </div>
          </div>
        )}
      </main>

      <StoreFooter />
    </div>
  );
}
