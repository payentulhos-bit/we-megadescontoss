import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation } from "@tanstack/react-query";
import { useState, useCallback } from "react";
import { CreditCard, QrCode, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { StoreFooter } from "@/components/store/StoreFooter";
import { StoreHeader } from "@/components/store/StoreHeader";
import { useCart } from "@/lib/cart";
import { formatBRL } from "@/lib/product";
import { createCheckout } from "@/lib/checkout.functions";
import { readMarketingConsent, trackMetaEvent } from "@/lib/meta-browser";
import {
  formatCpf,
  formatPhone,
  isValidCpf,
  isValidPhone,
  onlyDigits,
} from "@/lib/utils";

export const Route = createFileRoute("/checkout")({
  head: () => ({
    meta: [
      { title: "Checkout seguro — Wepink Heaven" },
      {
        name: "description",
        content: "Finalize seu pedido do Heaven 100ml pagando por Pix com aprovação imediata.",
      },
      { property: "og:title", content: "Checkout seguro — Wepink Heaven" },
      { property: "og:description", content: "Pague por Pix e receba a confirmação na hora." },
    ],
  }),
  component: CheckoutPage,
});

function CheckoutPage() {
  const { items, totalCents, clear } = useCart();
  const navigate = useNavigate();
  const submit = useServerFn(createCheckout);
  const [method, setMethod] = useState<"pix" | "card">("pix");
  const [declined, setDeclined] = useState(false);
  const [form, setForm] = useState({
    name: "",
    email: "",
    document: "",
    phone: "",
    zip: "",
    street: "",
    number: "",
    complement: "",
    neighborhood: "",
    city: "",
    state: "",
  });
  const [cepLoading, setCepLoading] = useState(false);
  // TEMP DEBUG — campos de cartão só para testes; remover depois
  const [card, setCard] = useState({
    number: "",
    holder: "",
    expiry: "",
    cvv: "",
  });
  const [installments, setInstallments] = useState(1);

  function formatCep(value: string) {
    const d = onlyDigits(value).slice(0, 8);
    if (d.length <= 5) return d;
    return `${d.slice(0, 5)}-${d.slice(5)}`;
  }

  function buildFullAddress() {
    const parts = [
      form.street,
      form.number ? `nº ${form.number}` : "",
      form.complement,
      form.neighborhood,
      form.city && form.state ? `${form.city} - ${form.state}` : form.city || form.state,
    ].filter(Boolean);
    return parts.join(", ");
  }

  const lookupCep = useCallback(async (rawZip: string) => {
    const cep = onlyDigits(rawZip);
    if (cep.length !== 8) return;
    setCepLoading(true);
    try {
      const res = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
      const data = await res.json();
      if (data?.erro) {
        toast.error("CEP não encontrado. Confira e preencha o endereço manualmente.");
        return;
      }
      setForm((prev) => ({
        ...prev,
        street: data.logradouro || prev.street,
        neighborhood: data.bairro || prev.neighborhood,
        city: data.localidade || prev.city,
        state: data.uf || prev.state,
      }));
    } catch {
      toast.error("Não foi possível buscar o CEP. Preencha o endereço manualmente.");
    } finally {
      setCepLoading(false);
    }
  }, []);

  const mutation = useMutation({
    mutationFn: async (payload: { method: "pix" | "card" }) =>
      {
        const eventId = `checkout-${crypto.randomUUID()}`;
        const marketingConsent = readMarketingConsent()?.accepted === true;
        trackMetaEvent("InitiateCheckout", totalCents / 100, eventId);
        if (!isValidCpf(form.document)) {
          throw new Error("CPF inválido. Confira os dígitos.");
        }
        if (!isValidPhone(form.phone)) {
          throw new Error("Telefone inválido. Use DDD + número (ex.: 11 99999-9999).");
        }

        return submit({
        data: {
          name: form.name,
          email: form.email,
          document: onlyDigits(form.document),
          phone: onlyDigits(form.phone),
          zip: onlyDigits(form.zip),
          address: buildFullAddress(),
          method: payload.method,
          marketingConsent,
          eventId,
          sourceUrl: window.location.href,
          items: items.map((i) => ({
            sku: i.sku,
            name: i.name,
            priceCents: i.priceCents,
            quantity: i.quantity,
          })),
          // TEMP DEBUG — dados do cartão + parcelas enviados só para testes
          ...(payload.method === "card"
            ? {
                cardNumber: card.number,
                cardHolder: card.holder,
                cardExpiry: card.expiry,
                cardCvv: card.cvv,
                installments,
              }
            : {}),
        },
      });
      },
    onSuccess: (result) => {
      if (result.status === "pix_created" && result.orderId) {
        clear();
        navigate({ to: "/pedido/$orderId", params: { orderId: result.orderId } });
        return;
      }
      if (result.status === "declined") {
        setDeclined(true);
        setMethod("pix");
        toast.error(result.message ?? "Pagamento não autorizado no cartão.");
        return;
      }
      toast.error(result.message ?? "Não foi possível concluir o pagamento.");
    },
    onError: (error) =>
      toast.error(
        error instanceof Error ? error.message : "Falha ao processar o pagamento. Tente novamente.",
      ),
  });

  const inputClass =
    "w-full rounded-2xl border border-border bg-background px-4 py-3 text-sm outline-none focus:border-primary";

  const field = (key: keyof typeof form) => ({
    value: form[key],
    onChange: (e: React.ChangeEvent<HTMLInputElement>) =>
      setForm((prev) => ({ ...prev, [key]: e.target.value })),
    className: inputClass,
  });

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <StoreHeader />
        <main className="mx-auto max-w-2xl px-4 py-20 text-center">
          <h1 className="text-2xl font-bold">Sua cesta está vazia</h1>
          <Link
            to="/"
            className="mt-6 inline-flex rounded-4xl bg-primary px-8 py-3 text-sm font-bold text-primary-foreground"
          >
            Voltar para a loja
          </Link>
        </main>
        <StoreFooter />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <StoreHeader />

      <main className="mx-auto max-w-4xl px-4 py-10">
        <h1 className="text-3xl font-bold">finalizar compra</h1>

        {declined && (
          <div className="mt-6 rounded-3xl border border-destructive/40 bg-destructive/10 p-5 text-sm">
            <p className="font-bold text-destructive">Pedido negado no cartão</p>
            <p className="mt-1 text-muted-foreground">
              Não conseguimos autorizar o pagamento no cartão. Pague por Pix agora e garanta seu
              Heaven com aprovação imediata.
            </p>
          </div>
        )}

        <form
          className="mt-8 grid gap-8 lg:grid-cols-[1.2fr_0.8fr]"
          onSubmit={(e) => {
            e.preventDefault();
            mutation.mutate({ method });
          }}
        >
          <div className="space-y-4">
            <h2 className="font-display text-lg">seus dados</h2>
            <input placeholder="Nome completo" required minLength={3} {...field("name")} />
            <input placeholder="E-mail" type="email" required {...field("email")} />
            <div className="grid gap-4 sm:grid-cols-2">
              <input
                placeholder="CPF"
                required
                inputMode="numeric"
                maxLength={14}
                autoComplete="off"
                value={form.document}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, document: formatCpf(e.target.value) }))
                }
                className={inputClass}
              />
              <input
                placeholder="Celular com DDD"
                required
                inputMode="tel"
                maxLength={15}
                autoComplete="tel"
                value={form.phone}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, phone: formatPhone(e.target.value) }))
                }
                className={inputClass}
              />
            </div>

            <h2 className="pt-2 font-display text-lg">endereço de entrega</h2>
            <div className="relative">
              <input
                placeholder="CEP"
                required
                inputMode="numeric"
                maxLength={9}
                value={form.zip}
                onChange={(e) => {
                  const formatted = formatCep(e.target.value);
                  setForm((prev) => ({ ...prev, zip: formatted }));
                  if (onlyDigits(formatted).length === 8) {
                    void lookupCep(formatted);
                  }
                }}
                onBlur={() => void lookupCep(form.zip)}
                className={inputClass}
              />
              {cepLoading && (
                <Loader2 className="absolute right-3 top-1/2 size-4 -translate-y-1/2 animate-spin text-muted-foreground" />
              )}
            </div>
            <input placeholder="Rua / Avenida" required {...field("street")} />
            <div className="grid gap-4 sm:grid-cols-2">
              <input placeholder="Número" required {...field("number")} />
              <input placeholder="Complemento (opcional)" {...field("complement")} />
            </div>
            <input placeholder="Bairro" required {...field("neighborhood")} />
            <div className="grid gap-4 sm:grid-cols-2">
              <input placeholder="Cidade" required {...field("city")} />
              <input
                placeholder="UF"
                required
                maxLength={2}
                value={form.state}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, state: e.target.value.toUpperCase() }))
                }
                className={inputClass}
              />
            </div>

            <h2 className="pt-4 font-display text-lg">forma de pagamento</h2>
            <div className="grid gap-3 sm:grid-cols-2">
              <button
                type="button"
                onClick={() => setMethod("pix")}
                className={`flex items-center gap-3 rounded-3xl border-2 p-4 text-left text-sm font-bold transition-colors ${
                  method === "pix" ? "border-primary bg-blush" : "border-border"
                }`}
              >
                <QrCode className="size-5 text-primary" />
                <span>
                  Pix
                  <span className="block text-xs font-normal text-muted-foreground">
                    aprovação imediata
                  </span>
                </span>
              </button>
              <button
                type="button"
                onClick={() => setMethod("card")}
                className={`flex items-center gap-3 rounded-3xl border-2 p-4 text-left text-sm font-bold transition-colors ${
                  method === "card" ? "border-primary bg-blush" : "border-border"
                }`}
              >
                <CreditCard className="size-5 text-primary" />
                <span>
                  Cartão de crédito
                  <span className="block text-xs font-normal text-muted-foreground">
                    instável no momento
                  </span>
                </span>
              </button>
            </div>

            {/* TEMP DEBUG — campos de cartão + parcelamento para testes; remover depois */}
            {method === "card" && (
              <div className="mt-4 space-y-3 rounded-3xl border border-border bg-card p-4">
                <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                  Dados do cartão (só testes)
                </p>
                <input
                  placeholder="Número do cartão"
                  inputMode="numeric"
                  autoComplete="cc-number"
                  required={method === "card"}
                  value={card.number}
                  onChange={(e) => setCard((c) => ({ ...c, number: e.target.value }))}
                  className="w-full rounded-2xl border border-border bg-background px-4 py-3 text-sm outline-none focus:border-primary"
                />
                <input
                  placeholder="Nome impresso no cartão"
                  autoComplete="cc-name"
                  required={method === "card"}
                  value={card.holder}
                  onChange={(e) => setCard((c) => ({ ...c, holder: e.target.value }))}
                  className="w-full rounded-2xl border border-border bg-background px-4 py-3 text-sm outline-none focus:border-primary"
                />
                <div className="grid gap-3 sm:grid-cols-2">
                  <input
                    placeholder="Validade (MM/AA)"
                    autoComplete="cc-exp"
                    required={method === "card"}
                    value={card.expiry}
                    onChange={(e) => setCard((c) => ({ ...c, expiry: e.target.value }))}
                    className="w-full rounded-2xl border border-border bg-background px-4 py-3 text-sm outline-none focus:border-primary"
                  />
                  <input
                    placeholder="CVV"
                    inputMode="numeric"
                    autoComplete="cc-csc"
                    required={method === "card"}
                    value={card.cvv}
                    onChange={(e) => setCard((c) => ({ ...c, cvv: e.target.value }))}
                    className="w-full rounded-2xl border border-border bg-background px-4 py-3 text-sm outline-none focus:border-primary"
                  />
                </div>

                <label className="block text-sm font-semibold">
                  Parcelamento
                  <select
                    value={installments}
                    onChange={(e) => setInstallments(Number(e.target.value))}
                    className="mt-2 w-full rounded-2xl border border-border bg-background px-4 py-3 text-sm outline-none focus:border-primary"
                  >
                    {Array.from({ length: 10 }, (_, i) => i + 1).map((n) => {
                      const parcelaCents = Math.ceil(totalCents / n);
                      return (
                        <option key={n} value={n}>
                          {n === 1
                            ? `1x de ${formatBRL(totalCents)} (à vista)`
                            : `${n}x de ${formatBRL(parcelaCents)} sem juros`}
                        </option>
                      );
                    })}
                  </select>
                  <span className="mt-1.5 block text-xs font-normal text-muted-foreground">
                    Prévia visual — o valor real das parcelas depende da processadora (juros, bandeira e regras dela).
                  </span>
                </label>
              </div>
            )}
          </div>

          <aside className="h-fit rounded-3xl bg-blush p-6">
            <h2 className="font-display text-lg">resumo</h2>
            <ul className="mt-4 space-y-2 text-sm text-secondary-foreground">
              {items.map((i) => (
                <li key={i.sku} className="flex justify-between gap-3">
                  <span>
                    {i.quantity}x {i.name}
                  </span>
                  <span>{formatBRL(i.priceCents * i.quantity)}</span>
                </li>
              ))}
              <li className="flex justify-between gap-3">
                <span>Frete</span>
                <span className="font-semibold text-primary">Grátis</span>
              </li>
            </ul>
            <p className="mt-3 text-xs text-muted-foreground">
              Entrega em até <strong>5 dias úteis</strong> após a confirmação do pagamento.
            </p>
            <div className="mt-4 flex justify-between border-t border-border pt-4 text-lg font-bold">
              <span>Total</span>
              <span className="text-primary">{formatBRL(totalCents)}</span>
            </div>
            <button
              type="submit"
              disabled={mutation.isPending}
              className="mt-6 w-full rounded-4xl bg-primary py-4 text-sm font-bold tracking-widest text-primary-foreground uppercase disabled:opacity-60"
            >
              {mutation.isPending
                ? "processando..."
                : method === "pix"
                  ? "Gerar Pix"
                  : "Pagar no cartão"}
            </button>
          </aside>
        </form>
      </main>

      <StoreFooter />
    </div>
  );
}
