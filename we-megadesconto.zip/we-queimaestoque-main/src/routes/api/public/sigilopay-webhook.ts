import { createFileRoute } from "@tanstack/react-router";
import { timingSafeEqual } from "crypto";
import { z } from "zod";

const webhookSchema = z
  .object({
    event: z.string().min(1).max(100),
    token: z.string().max(400).optional(),
    transaction: z
      .object({
        id: z.union([z.string(), z.number()]),
        status: z.string().max(100).optional(),
      })
      .passthrough(),
  })
  .passthrough();

function sameSecret(received: string, expected: string) {
  const receivedBytes = new TextEncoder().encode(received);
  const expectedBytes = new TextEncoder().encode(expected);
  return receivedBytes.length === expectedBytes.length && timingSafeEqual(receivedBytes, expectedBytes);
}

export const Route = createFileRoute("/api/public/sigilopay-webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let body: unknown;
        try {
          body = await request.json();
        } catch {
          return Response.json({ received: false }, { status: 400 });
        }

        const parsed = webhookSchema.safeParse(body);
        if (!parsed.success) return Response.json({ received: false }, { status: 400 });

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data: settings } = await supabaseAdmin
          .from("gateway_settings")
          .select("sigilopay_webhook_token")
          .limit(1)
          .maybeSingle();

        const expectedToken = settings?.sigilopay_webhook_token?.trim();
        const authorization = request.headers.get("authorization") ?? "";
        const authorizationToken = authorization.replace(/^Bearer\s+/i, "").trim();
        const receivedToken =
          request.headers.get("x-webhook-token") ??
          request.headers.get("x-token") ??
          (authorizationToken || parsed.data.token || "");

        if (!expectedToken || !sameSecret(receivedToken.trim(), expectedToken)) {
          return Response.json({ received: false }, { status: 401 });
        }

        const event = parsed.data.event.toUpperCase();
        const status = parsed.data.transaction.status?.toUpperCase() ?? "";
        if (event !== "TRANSACTION_PAID" && status !== "PAID") {
          return Response.json({ received: true });
        }

        const gatewayReference = String(parsed.data.transaction.id);
        const { data: order } = await supabaseAdmin
          .from("orders")
          .select("id, status, amount_cents, customer_email, customer_phone, customer_name, marketing_consent, meta_purchase_sent_at")
          .eq("gateway_reference", gatewayReference)
          .maybeSingle();

        if (!order) return Response.json({ received: true });

        if (order.status !== "paid") {
          await supabaseAdmin.from("orders").update({ status: "paid" }).eq("id", order.id);
        }

        if (order.marketing_consent && !order.meta_purchase_sent_at) {
          const { sendMetaEvent } = await import("@/lib/meta.server");
          const sent = await sendMetaEvent({
            eventName: "Purchase",
            eventId: `purchase-${order.id}`,
            value: order.amount_cents / 100,
            email: order.customer_email,
            phone: order.customer_phone ?? "",
            name: order.customer_name,
            sourceUrl: "https://we-queimaestoque.lovable.app",
          });
          if (sent) {
            await supabaseAdmin
              .from("orders")
              .update({ meta_purchase_sent_at: new Date().toISOString() })
              .eq("id", order.id)
              .is("meta_purchase_sent_at", null);
          }
        }

        return Response.json({ received: true });
      },
    },
  },
});