import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { supabase } from "@/integrations/supabase/client";
import { formatBRL } from "@/lib/product";
import {
  getGatewaySettings,
  listOrders,
  saveGatewaySettings,
} from "@/lib/admin.functions";

export const Route = createFileRoute("/_authenticated/painel")({
  head: () => ({
    meta: [
      { title: "Painel da loja — chave da gateway" },
      {
        name: "description",
        content: "Cadastre a chave da SigiloPay, ative Pix ou cartão e acompanhe os pedidos.",
      },
      { property: "og:title", content: "Painel da loja — chave da gateway" },
      { property: "og:description", content: "Configuração de pagamentos e pedidos da loja." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminPanel,
});

const STATUS_LABEL: Record<string, string> = {
  pending: "pendente",
  awaiting_payment: "aguardando Pix",
  paid: "pago",
  declined: "negado (cartão)",
  failed: "falhou",
};

function AdminPanel() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const fetchSettings = useServerFn(getGatewaySettings);
  const persistSettings = useServerFn(saveGatewaySettings);
  const fetchOrders = useServerFn(listOrders);

  const settingsQuery = useQuery({
    queryKey: ["gateway-settings"],
    queryFn: () => fetchSettings({ data: undefined }),
  });
  const ordersQuery = useQuery({
    queryKey: ["admin-orders"],
    queryFn: () => fetchOrders({ data: undefined }),
  });

  const [form, setForm] = useState({
    provider: "sigilopay",
    apiKey: "",
    apiSecret: "",
    baseUrl: "https://app.sigilopay.com.br/api/v1",
    pixEnabled: true,
    cardEnabled: true,
    metaPixelId: "",
    metaAccessToken: "",
    metaTestEventCode: "",
    metaTrackingEnabled: false,
    sigiloPayWebhookToken: "",
  });

  useEffect(() => {
    if (settingsQuery.data) {
      const s = settingsQuery.data;
      setForm({
        provider: s.provider,
        apiKey: s.apiKey,
        apiSecret: s.apiSecret,
        baseUrl: s.baseUrl,
        pixEnabled: s.pixEnabled,
        cardEnabled: s.cardEnabled,
        metaPixelId: s.metaPixelId,
        metaAccessToken: s.metaAccessToken,
        metaTestEventCode: s.metaTestEventCode,
        metaTrackingEnabled: s.metaTrackingEnabled,
        sigiloPayWebhookToken: s.sigiloPayWebhookToken,
      });
    }
  }, [settingsQuery.data]);

  const save = useMutation({
    mutationFn: () => persistSettings({ data: form }),
    onSuccess: () => {
      toast.success("Configurações de pagamento salvas");
      queryClient.invalidateQueries({ queryKey: ["gateway-settings"] });
    },
    onError: (error) =>
      toast.error(error instanceof Error ? error.message : "Não foi possível salvar."),
  });

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  const inputClass =
    "w-full rounded-2xl border border-border bg-background px-4 py-3 text-sm outline-none focus:border-primary";

  return (
    <div className="min-h-screen bg-blush">
      <header className="border-b border-border bg-background">
        <div className="mx-auto flex max-w-5xl items-center gap-4 px-4 py-4">
          <Link to="/" className="font-display text-xl font-extrabold text-primary">
            wepink
          </Link>
          <span className="text-sm text-muted-foreground">painel administrativo</span>
          <button onClick={signOut} className="ml-auto text-sm font-semibold text-primary">
            sair
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-5xl space-y-8 px-4 py-10">
        <section className="rounded-3xl bg-card p-6 shadow-card">
          <h1 className="text-2xl font-bold">gateway de pagamentos</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Cadastre a chave da sua gateway. O checkout usa esses dados para gerar as cobranças Pix.
          </p>

          {settingsQuery.isError && (
            <p className="mt-4 text-sm text-destructive">
              Acesso restrito ao administrador da loja.
            </p>
          )}

          <form
            className="mt-6 grid gap-4 sm:grid-cols-2"
            onSubmit={(e) => {
              e.preventDefault();
              save.mutate();
            }}
          >
            <label className="text-sm font-semibold">
              Gateway
              <input
                className={`mt-2 ${inputClass}`}
                value={form.provider}
                onChange={(e) => setForm({ ...form, provider: e.target.value })}
                placeholder="sigilopay"
                required
              />
            </label>
            <label className="text-sm font-semibold">
              URL da API
              <input
                className={`mt-2 ${inputClass}`}
                value={form.baseUrl}
                onChange={(e) => setForm({ ...form, baseUrl: e.target.value })}
                placeholder="https://app.sigilopay.com.br/api/v1"
                required
              />
            </label>
            <label className="text-sm font-semibold sm:col-span-2">
              Chave pública (x-public-key)
              <input
                className={`mt-2 ${inputClass}`}
                value={form.apiKey}
                onChange={(e) => setForm({ ...form, apiKey: e.target.value })}
                placeholder="cole aqui a chave pública da SigiloPay"
                autoComplete="off"
              />
            </label>
            <label className="text-sm font-semibold sm:col-span-2">
              Chave privada (x-secret-key)
              <input
                className={`mt-2 ${inputClass}`}
                value={form.apiSecret}
                onChange={(e) => setForm({ ...form, apiSecret: e.target.value })}
                placeholder="cole aqui a chave privada da SigiloPay"
                autoComplete="off"
              />
            </label>
            <label className="text-sm font-semibold sm:col-span-2">
              Token de validação do webhook
              <input
                type="password"
                className={`mt-2 ${inputClass}`}
                value={form.sigiloPayWebhookToken}
                onChange={(e) => setForm({ ...form, sigiloPayWebhookToken: e.target.value })}
                placeholder="cole o token mostrado no webhook da SigiloPay"
                autoComplete="off"
              />
              <span className="mt-2 block text-xs font-normal text-muted-foreground">
                URL do webhook: https://we-queimaestoque.lovable.app/api/public/sigilopay-webhook
              </span>
            </label>

            <label className="flex items-center gap-3 text-sm font-semibold">
              <input
                type="checkbox"
                checked={form.pixEnabled}
                onChange={(e) => setForm({ ...form, pixEnabled: e.target.checked })}
                className="size-4 accent-[oklch(0.58_0.24_355)]"
              />
              Aceitar Pix
            </label>
            <label className="flex items-center gap-3 text-sm font-semibold">
              <input
                type="checkbox"
                checked={form.cardEnabled}
                onChange={(e) => setForm({ ...form, cardEnabled: e.target.checked })}
                className="size-4 accent-[oklch(0.58_0.24_355)]"
              />
              Mostrar cartão no checkout (pedido sai negado e oferece Pix)
            </label>

            <button
              type="submit"
              disabled={save.isPending}
              className="rounded-4xl bg-primary py-3 text-sm font-bold tracking-widest text-primary-foreground uppercase disabled:opacity-60 sm:col-span-2"
            >
              {save.isPending ? "salvando..." : "Salvar configurações"}
            </button>
          </form>
        </section>

        <section className="rounded-3xl bg-card p-6 shadow-card">
          <h2 className="text-xl font-bold">conversões da Meta</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Configure o Pixel e a API de Conversões. O token fica protegido e nunca aparece para os clientes.
          </p>
          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            <label className="text-sm font-semibold">
              ID do Pixel
              <input
                className={`mt-2 ${inputClass}`}
                value={form.metaPixelId}
                onChange={(e) => setForm({ ...form, metaPixelId: e.target.value })}
                placeholder="Ex.: 123456789012345"
                inputMode="numeric"
              />
            </label>
            <label className="text-sm font-semibold">
              Código de teste (opcional)
              <input
                className={`mt-2 ${inputClass}`}
                value={form.metaTestEventCode}
                onChange={(e) => setForm({ ...form, metaTestEventCode: e.target.value })}
                placeholder="TEST12345"
              />
            </label>
            <label className="text-sm font-semibold sm:col-span-2">
              Token da API de Conversões
              <input
                type="password"
                className={`mt-2 ${inputClass}`}
                value={form.metaAccessToken}
                onChange={(e) => setForm({ ...form, metaAccessToken: e.target.value })}
                placeholder="Cole o token gerado no Gerenciador de Eventos"
                autoComplete="off"
              />
            </label>
            <label className="flex items-center gap-3 text-sm font-semibold sm:col-span-2">
              <input
                type="checkbox"
                checked={form.metaTrackingEnabled}
                onChange={(e) => setForm({ ...form, metaTrackingEnabled: e.target.checked })}
                className="size-4 accent-[oklch(0.58_0.24_355)]"
              />
              Ativar medição de checkout e compras
            </label>
            <p className="text-xs text-muted-foreground sm:col-span-2">
              Use o código de teste enquanto estiver verificando os eventos. Remova-o antes de anunciar de verdade.
            </p>
            <button
              type="button"
              disabled={save.isPending}
              onClick={() => save.mutate()}
              className="rounded-4xl bg-primary py-3 text-sm font-bold tracking-widest text-primary-foreground uppercase disabled:opacity-60 sm:col-span-2"
            >
              {save.isPending ? "salvando..." : "Salvar configuração da Meta"}
            </button>
          </div>
        </section>

        <section className="rounded-3xl bg-card p-6 shadow-card">
          <h2 className="text-xl font-bold">pedidos</h2>
          {ordersQuery.isLoading && (
            <p className="mt-4 text-sm text-muted-foreground">Carregando pedidos...</p>
          )}
          {ordersQuery.data && ordersQuery.data.length === 0 && (
            <p className="mt-4 text-sm text-muted-foreground">Nenhum pedido ainda.</p>
          )}
          {ordersQuery.data && ordersQuery.data.length > 0 && (
            <div className="mt-4 overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="text-xs tracking-widest text-muted-foreground uppercase">
                  <tr>
                    <th className="py-2">Data</th>
                    <th className="py-2">Cliente e entrega</th>
                    <th className="py-2">Itens</th>
                    <th className="py-2">Valor</th>
                    <th className="py-2">Forma</th>
                    <th className="py-2">Status</th>
                    <th className="py-2">Detalhe / Cartão (debug)</th>
                  </tr>
                </thead>
                <tbody>
                  {ordersQuery.data.map((order: any) => (
                    <tr key={order.id} className="border-t border-border align-top">
                      <td className="py-3 whitespace-nowrap">
                        {new Date(order.created_at).toLocaleString("pt-BR")}
                      </td>
                      <td className="py-3 min-w-[200px]">
                        <span className="font-semibold">{order.customer_name}</span>
                        <span className="block text-xs text-muted-foreground">
                          {order.customer_email}
                        </span>
                        {order.customer_document && (
                          <span className="block text-xs text-muted-foreground">
                            CPF: {order.customer_document}
                          </span>
                        )}
                        {order.customer_phone && (
                          <span className="block text-xs text-muted-foreground">
                            Tel: {order.customer_phone}
                          </span>
                        )}
                        {(order.shipping_zip || order.shipping_address) && (
                          <span className="mt-1 block text-xs text-muted-foreground">
                            {order.shipping_zip && <>CEP: {order.shipping_zip}<br /></>}
                            {order.shipping_address || "Endereço não informado"}
                          </span>
                        )}
                        {!order.shipping_zip && !order.shipping_address && (
                          <span className="mt-1 block text-xs text-amber-600">
                            ⚠ Endereço não preenchido
                          </span>
                        )}
                      </td>
                      <td className="py-3 text-xs">
                        {Array.isArray(order.items)
                          ? order.items.map((item: any, idx: number) => (
                              <span key={idx} className="block">
                                {item.quantity}x {item.name}
                              </span>
                            ))
                          : "—"}
                      </td>
                      <td className="py-3 whitespace-nowrap">{formatBRL(order.amount_cents)}</td>
                      <td className="py-3">{order.method === "pix" ? "Pix" : "Cartão"}</td>
                      <td className="py-3 whitespace-nowrap">
                        {STATUS_LABEL[order.status] ?? order.status}
                      </td>
                      <td className="py-3 max-w-xs">
                        {order.failure_reason ? (
                          <span className="block text-xs text-destructive break-all whitespace-pre-wrap">
                            {order.failure_reason}
                          </span>
                        ) : (
                          <span className="text-xs text-muted-foreground">—</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
