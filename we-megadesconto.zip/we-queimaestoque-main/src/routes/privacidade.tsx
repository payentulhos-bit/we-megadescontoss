import { createFileRoute } from "@tanstack/react-router";

import { StoreFooter } from "@/components/store/StoreFooter";
import { StoreHeader } from "@/components/store/StoreHeader";

export const Route = createFileRoute("/privacidade")({
  head: () => ({
    meta: [
      { title: "Política de Privacidade — Wepink Heaven" },
      { name: "description", content: "Como a loja usa e protege seus dados pessoais e preferências de anúncios." },
      { property: "og:title", content: "Política de Privacidade — Wepink Heaven" },
      { property: "og:description", content: "Conheça o uso e a proteção dos seus dados nesta loja." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <div className="min-h-screen bg-background">
      <StoreHeader />
      <main className="mx-auto max-w-3xl px-4 py-12">
        <h1 className="text-3xl font-bold">política de privacidade</h1>
        <div className="mt-8 space-y-6 text-sm leading-7 text-secondary-foreground">
          <section>
            <h2 className="text-lg font-bold text-foreground">Dados do pedido</h2>
            <p>Usamos nome, e-mail, CPF, telefone, endereço, itens e valor para processar o pagamento, identificar o pedido e viabilizar a entrega.</p>
          </section>
          <section>
            <h2 className="text-lg font-bold text-foreground">Medição de anúncios</h2>
            <p>Com sua autorização, enviamos à Meta eventos de início de checkout e compra, valor e moeda. Nome, e-mail e telefone são normalizados e protegidos por hash antes do envio para medição e otimização de anúncios.</p>
          </section>
          <section>
            <h2 className="text-lg font-bold text-foreground">Sua escolha</h2>
            <p>A decisão fica registrada com data e versão deste aviso. Você pode recusar ou retirar a autorização a qualquer momento em “Preferências de anúncios”, no rodapé. A retirada vale imediatamente para novos eventos.</p>
          </section>
          <section>
            <h2 className="text-lg font-bold text-foreground">Compartilhamento e proteção</h2>
            <p>Dados de pagamento são processados pela SigiloPay. Dados de medição autorizados são recebidos pela Meta. Tokens de integração ficam em área protegida e não são exibidos publicamente.</p>
          </section>
        </div>
      </main>
      <StoreFooter />
    </div>
  );
}