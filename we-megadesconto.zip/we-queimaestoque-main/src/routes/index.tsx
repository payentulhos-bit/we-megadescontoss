import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Minus, Plus, ShieldCheck, Truck } from "lucide-react";
import { toast } from "sonner";

import { StoreFooter } from "@/components/store/StoreFooter";
import { StoreHeader } from "@/components/store/StoreHeader";
import { useCart } from "@/lib/cart";
import { PRODUCT, formatBRL } from "@/lib/product";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Heaven Desodorante Colônia 100ml - Wepink" },
      {
        name: "description",
        content:
          "Heaven Desodorante Colônia 100ml: floral frutado com mandarina e flor de laranjeira. Compre com Pix e receba em casa.",
      },
      { property: "og:title", content: "Heaven Desodorante Colônia 100ml - Wepink" },
      {
        property: "og:description",
        content: "Um paraíso na terra: fragrância floral frutada de longa duração.",
      },
    ],
  }),
  component: ProductPage,
});

const TABS = ["Descrição", "Notas", "Modo de usar"] as const;

function ProductPage() {
  const [active, setActive] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [tab, setTab] = useState<(typeof TABS)[number]>("Descrição");
  const { add } = useCart();
  const navigate = useNavigate();

  const installment = Math.round(PRODUCT.priceCents / PRODUCT.installments);
  const discount = Math.round(
    ((PRODUCT.listPriceCents - PRODUCT.priceCents) / PRODUCT.listPriceCents) * 100,
  );

  function handleBuy() {
    add(quantity);
    toast.success("Produto adicionado à cesta");
    navigate({ to: "/carrinho" });
  }

  return (
    <div className="min-h-screen bg-background">
      <StoreHeader />

      <main className="mx-auto max-w-6xl px-4 py-8">
        <p className="text-xs text-muted-foreground">
          perfumaria / Best Seller / <span className="text-foreground">Heaven 100ml</span>
        </p>

        <div className="mt-6 grid gap-10 lg:grid-cols-2">
          <div>
            <div className="overflow-hidden rounded-3xl bg-blush">
              <img
                src={PRODUCT.images[active]}
                alt={`${PRODUCT.name} — foto ${active + 1}`}
                className="h-full w-full object-cover"
                width={800}
                height={800}
              />
            </div>
            <div className="mt-4 flex gap-3 overflow-x-auto">
              {PRODUCT.images.map((img, i) => (
                <button
                  key={img}
                  onClick={() => setActive(i)}
                  aria-label={`Ver foto ${i + 1}`}
                  className={`size-20 shrink-0 overflow-hidden rounded-2xl border-2 transition-colors ${
                    active === i ? "border-primary" : "border-transparent"
                  }`}
                >
                  <img src={img} alt="" loading="lazy" className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          <div>
            <span className="inline-flex rounded-4xl bg-primary px-4 py-1 text-[11px] font-bold tracking-widest text-primary-foreground uppercase">
              {PRODUCT.badge}
            </span>
            <h1 className="mt-4 text-3xl font-bold text-foreground sm:text-4xl">{PRODUCT.name}</h1>
            <p className="mt-2 text-lg text-muted-foreground">{PRODUCT.tagline}</p>

            <div className="mt-6 flex flex-wrap items-end gap-3">
              <span className="text-base text-muted-foreground line-through">
                {formatBRL(PRODUCT.listPriceCents)}
              </span>
              <span className="font-display text-4xl font-extrabold text-primary">
                {formatBRL(PRODUCT.priceCents)}
              </span>
              <span className="rounded-4xl bg-accent px-3 py-1 text-xs font-bold text-accent-foreground">
                -{discount}%
              </span>
            </div>
            <p className="mt-1 text-sm text-muted-foreground">
              ou {PRODUCT.installments}x {formatBRL(installment)}
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-4 rounded-4xl border border-border px-4 py-2">
                <button
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  aria-label="Diminuir quantidade"
                  className="text-primary"
                >
                  <Minus className="size-4" />
                </button>
                <span className="w-6 text-center text-sm font-bold">{quantity}</span>
                <button
                  onClick={() => setQuantity((q) => Math.min(99, q + 1))}
                  aria-label="Aumentar quantidade"
                  className="text-primary"
                >
                  <Plus className="size-4" />
                </button>
              </div>
              <button
                onClick={handleBuy}
                className="flex-1 rounded-4xl bg-primary px-10 py-4 text-sm font-bold tracking-widest text-primary-foreground uppercase shadow-soft transition-transform hover:scale-[1.01]"
              >
                Comprar
              </button>
            </div>

            <div className="mt-6 grid gap-3 text-sm text-muted-foreground sm:grid-cols-2">
              <p className="flex items-center gap-2">
                <Truck className="size-4 text-primary" /> Enviamos para todo o Brasil
              </p>
              <p className="flex items-center gap-2">
                <ShieldCheck className="size-4 text-primary" /> Pagamento por Pix aprovado na hora
              </p>
            </div>

            <div className="mt-8 rounded-3xl bg-blush p-6">
              <h2 className="font-display text-lg">Características</h2>
              <ul className="mt-3 space-y-2 text-sm text-secondary-foreground">
                {PRODUCT.features.map((f) => (
                  <li key={f}>• {f}</li>
                ))}
              </ul>
              <p className="mt-4 text-xs text-muted-foreground">
                Família olfativa: {PRODUCT.family.join(" · ")} — gênero {PRODUCT.gender}
              </p>
            </div>
          </div>
        </div>

        <section className="mt-14">
          <div className="flex gap-2 border-b border-border">
            {TABS.map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`rounded-t-2xl px-5 py-3 text-sm font-bold transition-colors ${
                  tab === t
                    ? "bg-blush text-primary"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {t}
              </button>
            ))}
          </div>
          <div className="rounded-b-3xl bg-blush p-6 text-sm leading-relaxed text-secondary-foreground">
            {tab === "Descrição" && <p>{PRODUCT.description}</p>}
            {tab === "Notas" && (
              <ul className="space-y-2">
                {PRODUCT.notes.map((n) => (
                  <li key={n.label}>
                    <strong>{n.label}:</strong> {n.value}
                  </li>
                ))}
              </ul>
            )}
            {tab === "Modo de usar" && <p>{PRODUCT.howTo}</p>}
          </div>
        </section>
      </main>

      <StoreFooter />
    </div>
  );
}
