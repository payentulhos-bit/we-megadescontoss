import { Link } from "@tanstack/react-router";
import { Search, ShoppingBag, User } from "lucide-react";

import { useCart } from "@/lib/cart";

const CATEGORIES = [
  "wehot",
  "kits",
  "bath&body",
  "body splash",
  "perfumaria",
  "skincare",
  "make",
  "hair",
  "roll-on",
];

export function StoreHeader() {
  const { count } = useCart();

  return (
    <header className="sticky top-0 z-40 bg-background">
      <div className="overflow-hidden bg-primary py-2 text-primary-foreground">
        <div className="marquee-track text-[11px] font-semibold tracking-[0.2em] uppercase">
          {Array.from({ length: 6 }).map((_, i) => (
            <span key={i} className="px-6">
              fique ligado! a inclusão do produto na cesta não garante sua compra. finalize o
              carrinho!
            </span>
          ))}
        </div>
      </div>

      <div className="mx-auto flex max-w-6xl items-center gap-4 px-4 py-4">
        <Link to="/" className="font-display text-2xl font-extrabold tracking-tight text-primary">
          wepink
        </Link>

        <div className="ml-auto hidden flex-1 items-center gap-2 rounded-4xl border border-border bg-muted px-4 py-2 md:flex">
          <Search className="size-4 text-muted-foreground" />
          <input
            className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            placeholder="o que você procura?"
            aria-label="Buscar produtos"
          />
        </div>

        <Link
          to="/auth"
          className="flex items-center gap-2 text-sm font-semibold text-foreground transition-colors hover:text-primary"
        >
          <User className="size-5" />
          <span className="hidden sm:inline">entrar</span>
        </Link>

        <Link
          to="/carrinho"
          className="relative flex items-center gap-2 text-sm font-semibold text-foreground transition-colors hover:text-primary"
          aria-label="Ver carrinho"
        >
          <ShoppingBag className="size-5" />
          {count > 0 && (
            <span className="absolute -top-2 -right-2 flex size-5 items-center justify-center rounded-full bg-primary text-[11px] font-bold text-primary-foreground">
              {count}
            </span>
          )}
        </Link>
      </div>

      <nav className="border-y border-border bg-blush">
        <ul className="mx-auto flex max-w-6xl gap-5 overflow-x-auto px-4 py-3 text-[13px] font-semibold whitespace-nowrap text-secondary-foreground">
          {CATEGORIES.map((c) => (
            <li key={c}>
              <Link to="/" className="transition-colors hover:text-primary">
                {c}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </header>
  );
}
