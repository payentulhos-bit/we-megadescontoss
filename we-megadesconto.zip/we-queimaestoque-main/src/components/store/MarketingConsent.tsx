import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";

import { getMetaPublicConfig } from "@/lib/meta.functions";
import {
  initializeMetaPixel,
  readMarketingConsent,
  writeMarketingConsent,
} from "@/lib/meta-browser";

const CONSENT_REGIONS = new Set([
  "AT", "BE", "BG", "BR", "HR", "CY", "CZ", "DE", "DK", "EE", "ES", "FI", "FR",
  "GR", "HU", "IE", "IS", "IT", "LI", "LT", "LU", "LV", "MT", "NL", "NO", "PL",
  "PT", "RO", "SE", "SI", "SK", "GB", "CH",
]);

export function MarketingConsentBanner() {
  const getConfig = useServerFn(getMetaPublicConfig);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    let active = true;
    async function configure() {
      const config = await getConfig();
      if (!active || !config.enabled) return;
      const saved = readMarketingConsent();
      if (saved?.accepted) {
        initializeMetaPixel(config.pixelId);
        return;
      }
      if (saved) return;

      let regulated = true;
      try {
        const controller = new AbortController();
        const timeout = window.setTimeout(() => controller.abort(), 2000);
        const response = await fetch("/cdn-cgi/trace", { signal: controller.signal });
        window.clearTimeout(timeout);
        const text = response.ok ? await response.text() : "";
        const location = text.match(/^loc=(.+)$/m)?.[1] ?? "XX";
        regulated = location === "XX" || location === "T1" || CONSENT_REGIONS.has(location);
      } catch {
        regulated = true;
      }

      if (regulated) setVisible(true);
      else initializeMetaPixel(config.pixelId);
    }
    configure();
    const open = () => setVisible(true);
    window.addEventListener("open-cookie-settings", open);
    return () => {
      active = false;
      window.removeEventListener("open-cookie-settings", open);
    };
  }, [getConfig]);

  if (!visible) return null;

  const decide = async (accepted: boolean) => {
    writeMarketingConsent(accepted);
    setVisible(false);
    if (accepted) {
      const config = await getConfig();
      if (config.enabled) initializeMetaPixel(config.pixelId);
    }
  };

  return (
    <aside className="fixed inset-x-4 bottom-4 z-50 mx-auto max-w-2xl rounded-2xl border border-border bg-card p-5 shadow-card" aria-label="Preferências de privacidade">
      <p className="font-bold">Sua privacidade</p>
      <p className="mt-1 text-sm text-muted-foreground">
        Com sua permissão, usamos a Meta para medir anúncios e compras. Você pode mudar sua escolha quando quiser.
      </p>
      <div className="mt-4 grid grid-cols-2 gap-3">
        <button className="rounded-4xl border border-primary py-3 text-sm font-bold text-primary" onClick={() => decide(false)}>
          Recusar
        </button>
        <button className="rounded-4xl bg-primary py-3 text-sm font-bold text-primary-foreground" onClick={() => decide(true)}>
          Aceitar
        </button>
      </div>
    </aside>
  );
}