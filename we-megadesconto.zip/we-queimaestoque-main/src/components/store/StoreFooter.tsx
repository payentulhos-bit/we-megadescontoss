import { Link } from "@tanstack/react-router";

export function StoreFooter() {
  return (
    <footer className="mt-16 border-t border-border bg-blush">
      <div className="mx-auto max-w-6xl px-4 py-12">
        <div className="rounded-2xl bg-primary px-6 py-8 text-primary-foreground">
          <h2 className="font-display text-2xl">receba dicas e novidades toda semana no seu e-mail</h2>
          <form
            className="mt-5 flex flex-col gap-3 sm:flex-row"
            onSubmit={(e) => e.preventDefault()}
          >
            <input
              type="email"
              required
              placeholder="seu melhor e-mail"
              aria-label="Seu e-mail"
              className="w-full rounded-4xl bg-background px-5 py-3 text-sm text-foreground outline-none"
            />
            <button
              type="submit"
              className="rounded-4xl bg-ink px-8 py-3 text-sm font-bold text-primary-foreground"
            >
              Enviar
            </button>
          </form>
        </div>

        <div className="mt-10 grid gap-8 text-sm sm:grid-cols-3">
          <div>
            <h3 className="font-display text-base">institucional</h3>
            <ul className="mt-3 space-y-2 text-muted-foreground">
              <li>Quem somos</li>
              <li>Trocas e devoluções</li>
              <li>
                <Link to="/privacidade" className="hover:text-primary">Política de privacidade</Link>
              </li>
              <li>
                <button
                  type="button"
                  className="hover:text-primary"
                  onClick={() => window.dispatchEvent(new Event("open-cookie-settings"))}
                >
                  Preferências de anúncios
                </button>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-display text-base">ajuda</h3>
            <ul className="mt-3 space-y-2 text-muted-foreground">
              <li>Rastreie seu pedido</li>
              <li>Formas de pagamento</li>
              <li>Fale com a gente</li>
            </ul>
          </div>
          <div>
            <h3 className="font-display text-base">loja</h3>
            <ul className="mt-3 space-y-2 text-muted-foreground">
              <li>
                <Link to="/carrinho" className="hover:text-primary">
                  Meu carrinho
                </Link>
              </li>
              <li>
                <Link to="/auth" className="hover:text-primary">
                  Painel do administrador
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <p className="mt-10 text-xs text-muted-foreground">
          Pagamentos processados por Pix via SigiloPay. Loja demonstrativa inspirada no layout
          wepink.
        </p>
      </div>
    </footer>
  );
}
