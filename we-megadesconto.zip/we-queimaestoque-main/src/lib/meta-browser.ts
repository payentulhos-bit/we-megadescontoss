export const META_CONSENT_KEY = "wepink-marketing-consent-v1";

export type MarketingConsent = {
  accepted: boolean;
  decidedAt: string;
  noticeVersion: "2026-09-16";
};

declare global {
  interface Window {
    fbq?: (...args: unknown[]) => void;
    _fbq?: unknown;
  }
}

export function readMarketingConsent(): MarketingConsent | null {
  try {
    const value = localStorage.getItem(META_CONSENT_KEY);
    return value ? (JSON.parse(value) as MarketingConsent) : null;
  } catch {
    return null;
  }
}

export function writeMarketingConsent(accepted: boolean) {
  const choice: MarketingConsent = {
    accepted,
    decidedAt: new Date().toISOString(),
    noticeVersion: "2026-09-16",
  };
  localStorage.setItem(META_CONSENT_KEY, JSON.stringify(choice));
  window.dispatchEvent(new CustomEvent("marketing-consent-change", { detail: choice }));
}

export function initializeMetaPixel(pixelId: string) {
  if (!pixelId || window.fbq) return;
  const fbq = (...args: unknown[]) => {
    (fbq as unknown as { queue: unknown[][] }).queue.push(args);
  };
  (fbq as unknown as { queue: unknown[][] }).queue = [];
  window.fbq = fbq;
  const script = document.createElement("script");
  script.async = true;
  script.src = "https://connect.facebook.net/en_US/fbevents.js";
  document.head.appendChild(script);
  window.fbq("init", pixelId);
  window.fbq("track", "PageView");
}

export function trackMetaEvent(name: "InitiateCheckout" | "Purchase", value: number, eventId: string) {
  window.fbq?.("track", name, { value, currency: "BRL" }, { eventID: eventId });
}