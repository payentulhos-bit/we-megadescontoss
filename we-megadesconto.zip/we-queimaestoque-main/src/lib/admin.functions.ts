import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const settingsSchema = z.object({
  provider: z.string().min(2).max(60),
  apiKey: z.string().max(400),
  apiSecret: z.string().max(400),
  baseUrl: z.string().url(),
  pixEnabled: z.boolean(),
  cardEnabled: z.boolean(),
  metaPixelId: z.string().max(40),
  metaAccessToken: z.string().max(600),
  metaTestEventCode: z.string().max(100),
  metaTrackingEnabled: z.boolean(),
  sigiloPayWebhookToken: z.string().max(400),
});

async function assertAdmin(context: { supabase: any; userId: string }) {
  const { data: isAdmin, error } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "admin",
  });
  if (error) throw new Error(error.message);
  if (!isAdmin) throw new Error("Acesso restrito ao administrador.");
}

export const getGatewaySettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context as any);
    const { data, error } = await (context as any).supabase
      .from("gateway_settings")
      .select("*")
      .limit(1)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return {
      provider: data?.provider ?? "sigilopay",
      apiKey: data?.api_key ?? "",
      apiSecret: data?.api_secret ?? "",
      baseUrl: data?.base_url ?? "https://app.sigilopay.com.br/api/v1",
      pixEnabled: data?.pix_enabled ?? true,
      cardEnabled: data?.card_enabled ?? true,
      metaPixelId: data?.meta_pixel_id ?? "",
      metaAccessToken: data?.meta_access_token ?? "",
      metaTestEventCode: data?.meta_test_event_code ?? "",
      metaTrackingEnabled: data?.meta_tracking_enabled ?? false,
      sigiloPayWebhookToken: data?.sigilopay_webhook_token ?? "",
      updatedAt: data?.updated_at ?? null,
    };
  });

export const saveGatewaySettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: z.infer<typeof settingsSchema>) => settingsSchema.parse(data))
  .handler(async ({ data, context }) => {
    await assertAdmin(context as any);
    const supabase = (context as any).supabase;
    const { data: existing } = await supabase.from("gateway_settings").select("id").limit(1).maybeSingle();

    const payload = {
      provider: data.provider,
      api_key: data.apiKey,
      api_secret: data.apiSecret,
      base_url: data.baseUrl,
      pix_enabled: data.pixEnabled,
      card_enabled: data.cardEnabled,
      meta_pixel_id: data.metaPixelId,
      meta_access_token: data.metaAccessToken,
      meta_test_event_code: data.metaTestEventCode,
      meta_tracking_enabled: data.metaTrackingEnabled,
      sigilopay_webhook_token: data.sigiloPayWebhookToken,
      updated_at: new Date().toISOString(),
      updated_by: (context as any).userId,
    };

    const { error } = existing
      ? await supabase.from("gateway_settings").update(payload).eq("id", existing.id)
      : await supabase.from("gateway_settings").insert(payload);

    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const listOrders = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context as any);
    const { data, error } = await (context as any).supabase
      .from("orders")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(100);
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const checkIsAdmin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await (context as any).supabase.rpc("has_role", {
      _user_id: (context as any).userId,
      _role: "admin",
    });
    return Boolean(data);
  });
