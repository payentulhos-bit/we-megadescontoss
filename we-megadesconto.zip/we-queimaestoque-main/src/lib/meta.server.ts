import { createHash } from "crypto";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export async function sendMetaEvent(input: {
  eventName: "InitiateCheckout" | "Purchase";
  eventId: string;
  value: number;
  email: string;
  phone: string;
  name: string;
  sourceUrl: string;
}) {
  const { data: settings } = await supabaseAdmin
    .from("gateway_settings")
    .select("meta_pixel_id, meta_access_token, meta_test_event_code, meta_tracking_enabled")
    .limit(1)
    .maybeSingle();

  if (!settings?.meta_tracking_enabled || !settings.meta_pixel_id || !settings.meta_access_token) return false;

  const hash = (value: string) => createHash("sha256").update(value.trim().toLowerCase()).digest("hex");
  const nameParts = input.name.trim().split(/\s+/);
  const userData: Record<string, string[]> = { em: [hash(input.email)], fn: [hash(nameParts[0] ?? "")] };
  const lastName = nameParts.slice(1).join(" ");
  if (lastName) userData["ln"] = [hash(lastName)];
  const phone = input.phone.replace(/\D/g, "");
  if (phone) userData["ph"] = [hash(phone)];

  const body: Record<string, unknown> = {
    data: [{
      event_name: input.eventName,
      event_time: Math.floor(Date.now() / 1000),
      event_id: input.eventId,
      action_source: "website",
      event_source_url: input.sourceUrl || undefined,
      user_data: userData,
      custom_data: { currency: "BRL", value: input.value },
    }],
  };
  if (settings.meta_test_event_code) body["test_event_code"] = settings.meta_test_event_code;

  try {
    const response = await fetch(
      `https://graph.facebook.com/v21.0/${encodeURIComponent(settings.meta_pixel_id)}/events?access_token=${encodeURIComponent(settings.meta_access_token)}`,
      { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) },
    );
    return response.ok;
  } catch {
    return false;
  }
}