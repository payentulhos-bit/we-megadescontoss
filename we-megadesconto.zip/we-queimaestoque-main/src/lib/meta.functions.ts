import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export const getMetaPublicConfig = createServerFn({ method: "GET" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin
    .from("gateway_settings")
    .select("meta_pixel_id, meta_tracking_enabled")
    .limit(1)
    .maybeSingle();

  return {
    pixelId: data?.meta_tracking_enabled ? (data.meta_pixel_id ?? "") : "",
    enabled: Boolean(data?.meta_tracking_enabled && data?.meta_pixel_id),
  };
});

export const markPurchaseForMeta = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        orderId: z.string().uuid(),
        consent: z.literal(true),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: order } = await supabaseAdmin
      .from("orders")
      .select("id, status, amount_cents, customer_email, customer_phone, customer_name, meta_event_id, meta_purchase_sent_at")
      .eq("id", data.orderId)
      .maybeSingle();

    if (!order || order.status !== "paid" || order.meta_purchase_sent_at) return { sent: false };

    const eventId = `purchase-${order.id}`;
    const { sendMetaEvent } = await import("@/lib/meta.server");
    const sent = await sendMetaEvent({
      eventName: "Purchase",
      eventId,
      value: order.amount_cents / 100,
      email: order.customer_email,
      phone: order.customer_phone ?? "",
      name: order.customer_name,
      sourceUrl: "",
    });
    if (sent) {
      await supabaseAdmin
        .from("orders")
        .update({ meta_purchase_sent_at: new Date().toISOString() })
        .eq("id", order.id)
        .is("meta_purchase_sent_at", null);
    }
    return { sent, eventId };
  });