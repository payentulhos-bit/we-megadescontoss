import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

import { PRODUCT } from "./product";

export type CartItem = {
  sku: string;
  name: string;
  priceCents: number;
  quantity: number;
};

type CartContextValue = {
  items: CartItem[];
  count: number;
  totalCents: number;
  add: (quantity?: number) => void;
  setQuantity: (sku: string, quantity: number) => void;
  remove: (sku: string) => void;
  clear: () => void;
};

const CartContext = createContext<CartContextValue | null>(null);
const STORAGE_KEY = "wepink-cart-v1";

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) setItems(JSON.parse(raw) as CartItem[]);
    } catch {
      setItems([]);
    }
  }, []);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch {
      /* ignore */
    }
  }, [items]);

  const value = useMemo<CartContextValue>(() => {
    const totalCents = items.reduce((sum, i) => sum + i.priceCents * i.quantity, 0);
    return {
      items,
      count: items.reduce((sum, i) => sum + i.quantity, 0),
      totalCents,
      add: (quantity = 1) =>
        setItems((prev) => {
          const found = prev.find((i) => i.sku === PRODUCT.sku);
          if (found) {
            return prev.map((i) =>
              i.sku === PRODUCT.sku ? { ...i, quantity: i.quantity + quantity } : i,
            );
          }
          return [
            ...prev,
            {
              sku: PRODUCT.sku,
              name: PRODUCT.name,
              priceCents: PRODUCT.priceCents,
              quantity,
            },
          ];
        }),
      setQuantity: (sku, quantity) =>
        setItems((prev) =>
          quantity <= 0
            ? prev.filter((i) => i.sku !== sku)
            : prev.map((i) => (i.sku === sku ? { ...i, quantity } : i)),
        ),
      remove: (sku) => setItems((prev) => prev.filter((i) => i.sku !== sku)),
      clear: () => setItems([]),
    };
  }, [items]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart precisa estar dentro de CartProvider");
  return ctx;
}
