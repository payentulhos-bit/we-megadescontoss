import heaven1 from "@/assets/heaven-1.jpg";
import heaven2 from "@/assets/heaven-2.jpg";
import heaven3 from "@/assets/heaven-3.jpg";
import heaven4 from "@/assets/heaven-4.jpg";
import heaven5 from "@/assets/heaven-5.jpg";

export const PRODUCT = {
  sku: "heaven-100ml",
  name: "Heaven Desodorante Colônia 100ml - Wepink",
  tagline: "um paraíso na terra",
  badge: "Best Seller",
  listPriceCents: 32900,
  priceCents: 7389,
  installments: 6,
  images: [heaven3, heaven4, heaven2, heaven1, heaven5],
  features: [
    "Caminho olfativo: Floral Frutado",
    "Amadeirado",
    "Longa duração",
    "Qualidade incrível",
    "Aroma marcante",
    "Essência exclusiva e única",
  ],
  description:
    "O Desodorante Colônia Wepink Heaven é um convite a um universo delicado e alegre, em uma jornada sensorial capaz de transportar ao paraíso. Sua essência ascende à felicidade em um caminho olfativo floral, evoluindo em notas elegantes de mandarina e flor de laranjeira. Finaliza em um fundo doce e amadeirado, trazendo o encanto de uma fragrância leve e inebriante.",
  notes: [
    { label: "Saída", value: "Mandarina e flor de laranjeira" },
    { label: "Corpo", value: "Floral frutado, com acordes de pêssego" },
    { label: "Fundo", value: "Doce e amadeirado" },
  ],
  howTo:
    "Aplique nos pontos de pulsação — pulsos, colo e atrás das orelhas — mantendo o frasco a cerca de 15 cm da pele. Evite friccionar após a aplicação para preservar a fragrância por mais tempo.",
  family: ["floral 🌸", "frutado 🍑"],
  gender: "feminino",
};

export function formatBRL(cents: number) {
  return (cents / 100).toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  });
}
