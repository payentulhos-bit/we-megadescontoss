# Corrigir build do webhook SigiloPay

## Objetivo
Restaurar a compilação e deixar o webhook compatível com as colunas necessárias para confirmar pagamentos e registrar conversões.

## Alterações
- Corrigir a expressão de leitura do token no webhook, evitando a combinação inválida de `??` com `||`.
- Criar e aplicar uma migração aditiva para o token do webhook e o consentimento de marketing.
- Atualizar os tipos gerados do banco após a migração.
- Validar a compilação e o endpoint do webhook sem realizar uma cobrança real.

## Detalhes técnicos
- Adicionar `gateway_settings.sigilopay_webhook_token` como texto opcional.
- Adicionar `orders.marketing_consent` como booleano obrigatório, padrão `false`.
- Não alterar pedidos existentes, chaves já salvas ou políticas de acesso.
