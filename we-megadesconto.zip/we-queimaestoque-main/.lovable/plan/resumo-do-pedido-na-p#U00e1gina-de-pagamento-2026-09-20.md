# Resumo do pedido na página de pagamento

## Objetivo
Deixar claro o que o cliente está pagando na tela do Pix, reduzindo dúvidas e abandono.

## Alterações
- Exibir foto, nome, quantidade, valor unitário e subtotal de cada produto.
- Mostrar número do pedido, valor total e status do pagamento em português.
- Exibir o primeiro nome do cliente e um resumo do endereço informado, sem revelar CPF ou e-mail.
- Organizar o conteúdo para que o resumo permaneça visível ao lado do QR Code em telas grandes e acima dele no celular.
- Manter o Pix Copia e Cola e a geração automática da imagem do QR Code como estão.

## Detalhes técnicos
- Ampliar somente os dados públicos do pedido necessários para montar o resumo (`items`, endereço e CEP).
- Validar os itens recebidos antes de exibi-los e relacionar a imagem ao produto cadastrado.
- Conferir compilação e aparência em desktop e celular.
