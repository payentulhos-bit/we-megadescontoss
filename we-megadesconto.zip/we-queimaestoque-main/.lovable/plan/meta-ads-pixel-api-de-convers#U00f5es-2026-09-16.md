# Meta Ads: Pixel + API de Conversões

## Objetivo
Adicionar ao painel administrativo a configuração do Meta Pixel e da API de Conversões, sem expor o token secreto no navegador.

## O que será construído
- Campos no painel para Pixel ID, token da API de Conversões, código de teste e ativação do rastreamento.
- Registro de `InitiateCheckout` quando o cliente inicia a finalização da compra.
- Registro de `Purchase` somente quando o pedido estiver confirmado como pago.
- Mesmo identificador de evento no navegador e no servidor para evitar conversões duplicadas.
- Consentimento de publicidade com aceitar e recusar em igualdade, além de opção para alterar a escolha depois.
- Página de privacidade explicando quais dados são usados, para qual finalidade e como retirar o consentimento.

## Segurança e privacidade
- O token da Meta ficará salvo apenas no banco protegido e será utilizado somente no servidor.
- Dados pessoais não serão colocados em URLs nem enviados sem consentimento de publicidade.
- A escolha de consentimento será registrada no navegador com data e versão do aviso.
- Em locais que exigem consentimento, o rastreamento ficará bloqueado até a escolha do visitante.

## Detalhes técnicos
- Ampliar as configurações administrativas existentes com os dados da Meta.
- Criar funções públicas limitadas para fornecer apenas o Pixel ID ativo e registrar eventos autorizados.
- Enviar eventos do servidor para a Graph API da Meta com dados normalizados e protegidos por hash.
- Usar o ID do pedido como referência do evento de compra e guardar o estado de envio para não repetir.
- Exibir no painel o estado da configuração e orientação para teste no Gerenciador de Eventos.

## Limite desta etapa
A instalação ficará pronta no site e no painel. A validação final no Meta Events Manager dependerá do Pixel ID, token e código de teste fornecidos pelo administrador.
