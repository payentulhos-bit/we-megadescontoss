ALTER TABLE public.gateway_settings
  ADD COLUMN meta_pixel_id text,
  ADD COLUMN meta_access_token text,
  ADD COLUMN meta_test_event_code text,
  ADD COLUMN meta_tracking_enabled boolean NOT NULL DEFAULT false;

ALTER TABLE public.orders
  ADD COLUMN meta_event_id text,
  ADD COLUMN meta_purchase_sent_at timestamptz;

CREATE UNIQUE INDEX orders_meta_event_id_unique
  ON public.orders (meta_event_id)
  WHERE meta_event_id IS NOT NULL;