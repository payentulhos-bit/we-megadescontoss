ALTER TABLE public.gateway_settings
  ADD COLUMN IF NOT EXISTS sigilopay_webhook_token text;

ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS marketing_consent boolean NOT NULL DEFAULT false;